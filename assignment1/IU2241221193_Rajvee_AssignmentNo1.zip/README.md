Submitting Date: 02/08/2024

Assignment Level: Easy

Code Quality: Maintained

Comments: Added to explain the logic and steps within the code.

Notes
Each function is provided with a brief description at the top.
Code is formatted for readability.
Variable names are chosen to be meaningful.

Steps to Run the Code
1.Install Node.js
2.Save the JavaScript code in a file named assignment.js
3.Open a terminal or command prompt
4.Navigate to the directory where the assignment.js file is saved
5.Execute "node assignment.js" command in the terminal
